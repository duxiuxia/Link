#ifndef apollo_exceptions_hpp_
#define apollo_exceptions_hpp_

#include <boost/exception/all.hpp>

namespace apollo {

} /* namespace apollo */

#endif // apollo_exceptions_hpp_
